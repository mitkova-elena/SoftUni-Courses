from django.apps import AppConfig


class CarCollectionAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'car_collection.car_collection_app'
