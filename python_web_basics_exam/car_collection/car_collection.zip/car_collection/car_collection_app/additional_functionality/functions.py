from car_collection.car_collection_app.models import ProfileModel


def get_profile():
    try:
        profiles = ProfileModel.objects.get()
        return profiles
    except ProfileModel.DoesNotExist as ex:
        return None

